# 🚀 PANDUAN DEPLOY APLIKASI LV SERVICE MONITOR ONLINE

## 📱 VERSI FINAL SUDAH SIAP PAKAI!

Aplikasi LV Service Monitor versi final sudah **100% mobile-responsive** dan siap digunakan di HP/Tablet!

### ✅ Fitur yang Sudah Ditambahkan:
1. **Login Password Only** - Tidak perlu username, langsung password saja
2. **Password Tersembunyi** - Default password TIDAK ditampilkan di layar
3. **Optimasi Mobile** - Sempurna untuk HP Android & iPhone
4. **Auto-Sync** - Data otomatis tersimpan di browser (localStorage)
5. **Touch-Friendly** - Semua tombol responsif untuk sentuhan

### 🔐 PASSWORD DEFAULT:
```
muliabara2025
```
**PENTING:** Ganti password di baris 494 file HTML:
```javascript
const ADMIN_PASSWORD = "muliabara2025"; // ← GANTI DI SINI
```

---

## 🌐 CARA MEMBUAT APLIKASI ONLINE (3 PILIHAN)

### **PILIHAN 1: GitHub Pages (PALING MUDAH & GRATIS)** ⭐ RECOMMENDED

#### Langkah-langkah:

1. **Buat Akun GitHub**
   - Buka https://github.com
   - Klik "Sign up" (kalau belum punya akun)

2. **Upload File HTML**
   - Klik tombol "+" di kanan atas → "New repository"
   - Nama repository: `lv-service-monitor`
   - Centang "Public"
   - Centang "Add a README file"
   - Klik "Create repository"

3. **Upload File**
   - Di repository yang baru dibuat, klik "Add file" → "Upload files"
   - Drag & drop file `LV_Service_Monitor_Final.html`
   - **RENAME file menjadi `index.html`** (PENTING!)
   - Klik "Commit changes"

4. **Aktifkan GitHub Pages**
   - Klik tab "Settings" (di menu repository)
   - Scroll ke bawah, klik "Pages" di menu kiri
   - Di bagian "Source", pilih "main" branch
   - Klik "Save"
   - Tunggu 1-2 menit

5. **Selesai! Aplikasi Sudah Online 🎉**
   - URL aplikasi: `https://[username-github-kamu].github.io/lv-service-monitor`
   - Contoh: `https://johndoe.github.io/lv-service-monitor`
   - Bisa dibuka di HP, Tablet, atau Komputer!

**CATATAN PENTING GITHUB:**
- Data tersimpan di localStorage browser masing-masing device
- Belum ada sync antar device (lihat Pilihan 3 untuk sync online)

---

### **PILIHAN 2: Netlify Drop (SUPER CEPAT)** 

#### Langkah-langkah:

1. **Buka Netlify Drop**
   - Buka https://app.netlify.com/drop
   - TIDAK perlu login/daftar!

2. **Drag & Drop File**
   - Rename file `LV_Service_Monitor_Final.html` → `index.html`
   - Drag & drop file `index.html` ke area Netlify Drop

3. **Selesai! Langsung Online 🎉**
   - Netlify akan generate URL random
   - Contoh: `https://wonderful-pasteur-abc123.netlify.app`
   - URL bisa di-customize (login gratis ke Netlify)

**CATATAN NETLIFY:**
- Gratis selamanya
- Lebih cepat dari GitHub Pages
- Data tersimpan di localStorage browser

---

### **PILIHAN 3: Firebase Hosting + Firestore (SYNC ONLINE REAL)** 🔥

Ini pilihan terbaik kalau mau data sync antar semua device (HP, Tablet, Komputer)

#### Langkah-langkah:

1. **Setup Firebase Project**
   - Buka https://console.firebase.google.com
   - Klik "Add project" / "Tambah project"
   - Nama project: "LV Service Monitor"
   - Klik "Continue" sampai selesai

2. **Buat Web App**
   - Di Firebase Console, klik ikon "</>" (Web)
   - App nickname: "LV Monitor"
   - Centang "Firebase Hosting"
   - Klik "Register app"

3. **Copy Firebase Config**
   - Akan muncul kode seperti ini:
   ```javascript
   const firebaseConfig = {
     apiKey: "AIza...",
     authDomain: "...",
     projectId: "...",
     storageBucket: "...",
     messagingSenderId: "...",
     appId: "..."
   };
   ```
   - COPY semua kode ini!

4. **Update File HTML**
   - Buka file `LV_Service_Monitor_Final.html`
   - Cari baris 494 (tempat password)
   - Tambahkan kode Firebase di bawahnya:
   
   ```html
   <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore-compat.js"></script>
   <script>
   // Firebase Configuration (PASTE CONFIG DI SINI)
   const firebaseConfig = {
     // ... paste config dari step 3
   };
   
   firebase.initializeApp(firebaseConfig);
   const db = firebase.firestore();
   
   // Ganti function saveToCloud() dengan ini:
   function saveToCloud() {
     const data = {
       records: records,
       driverReports: driverReports,
       lastSync: new Date().toISOString()
     };
     
     db.collection('lv_data').doc('main').set(data)
       .then(() => showSyncStatus("Data tersinkronisasi online", true))
       .catch(err => console.error(err));
   }
   
   // Ganti function loadFromCloud() dengan ini:
   function loadFromCloud() {
     db.collection('lv_data').doc('main').get()
       .then(doc => {
         if (doc.exists) {
           const data = doc.data();
           records = data.records || [];
           driverReports = data.driverReports || [];
           showSyncStatus("Data dimuat dari cloud", true);
         }
       })
       .catch(err => console.error(err));
   }
   </script>
   ```

5. **Setup Firestore Database**
   - Di Firebase Console, klik "Firestore Database"
   - Klik "Create database"
   - Pilih "Start in test mode"
   - Klik "Enable"

6. **Deploy ke Firebase Hosting**
   - Install Firebase CLI di komputer:
   ```bash
   npm install -g firebase-tools
   ```
   
   - Login Firebase:
   ```bash
   firebase login
   ```
   
   - Init Firebase di folder project:
   ```bash
   firebase init hosting
   ```
   - Pilih project yang sudah dibuat
   - Public directory: `.` (titik)
   - Single-page app: Yes
   
   - Deploy:
   ```bash
   firebase deploy
   ```

7. **Selesai! Aplikasi Online dengan Sync Real-Time 🎉**
   - URL: `https://[project-id].web.app`
   - Data sync otomatis ke semua device!

---

## 📲 CARA PAKAI DI HP (Semua Pilihan)

### **Buat Icon di Home Screen (Android)**
1. Buka URL aplikasi di Chrome
2. Tap menu (3 titik) → "Add to Home screen"
3. Kasih nama "LV Monitor"
4. Klik "Add"
5. Selesai! Icon muncul di home screen seperti app asli

### **Buat Icon di Home Screen (iPhone)**
1. Buka URL aplikasi di Safari
2. Tap icon "Share" (kotak dengan panah)
3. Scroll ke bawah → tap "Add to Home Screen"
4. Kasih nama "LV Monitor"
5. Tap "Add"
6. Selesai! Icon muncul di home screen

---

## ⚡ TIPS & TRIK

### **Ganti Password Admin:**
Edit file HTML di baris 494:
```javascript
const ADMIN_PASSWORD = "passwordbaru123";
```

### **Tambah Unit Master:**
Edit file HTML di baris 511-517, tambahkan unit baru:
```javascript
const MASTER_UNITS = [
  { unitNo: "LV-001", platNomor: "KT 1001 AB", merk: "Toyota Hilux", tahun: "2020" },
  { unitNo: "LV-006", platNomor: "KT 1006 AB", merk: "Honda CR-V", tahun: "2023" }, // ← unit baru
];
```

### **Backup Data:**
1. Login ke dashboard HR/GA
2. Klik tombol "📥 Export"
3. File Excel akan terdownload otomatis
4. Simpan file sebagai backup

### **Restore Data:**
- Data tersimpan di browser localStorage
- Untuk restore, bisa import Excel manual atau copy localStorage

---

## 🆘 TROUBLESHOOTING

### **Aplikasi tidak bisa dibuka di HP?**
- Pastikan file sudah di-rename jadi `index.html`
- Clear cache browser HP (Settings → Apps → Chrome/Safari → Clear cache)
- Coba browser lain (Firefox, Edge, dll)

### **Data hilang setelah clear cache?**
- Gunakan Firebase (Pilihan 3) untuk sync online
- Atau export Excel secara berkala sebagai backup

### **Password tidak bisa login?**
- Cek password di baris 494 file HTML
- Password default: `muliabara2025`
- Case-sensitive (huruf besar/kecil harus sama)

### **Grafik tidak muncul?**
- Pastikan koneksi internet stabil
- Chart.js perlu download dari CDN
- Refresh halaman (F5 atau pull-down di HP)

---

## 📞 SUPPORT

Jika ada masalah atau pertanyaan:
1. Cek bagian Troubleshooting di atas
2. Review kembali langkah-langkah deploy
3. Pastikan semua library sudah ter-load (cek Console browser)

---

## 🎯 RINGKASAN

**PILIHAN TERBAIK:**
- **Pemula/Simple:** GitHub Pages (Pilihan 1)
- **Cepat/Instant:** Netlify Drop (Pilihan 2)  
- **Pro/Sync Real:** Firebase (Pilihan 3)

**Semua pilihan 100% GRATIS SELAMANYA!**

---

**SELAMAT MENGGUNAKAN! 🚀**

Aplikasi LV Service Monitor sudah siap digunakan untuk monitoring kendaraan operasional Muliabara Mining Fleet!